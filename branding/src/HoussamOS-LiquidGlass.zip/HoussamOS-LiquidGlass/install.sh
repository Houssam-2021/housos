#!/usr/bin/env bash
# HoussamOS Liquid Glass — per-user install. No root required.
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="${HOME}/.local/share/icons/HoussamOS-LiquidGlass"
mkdir -p "${HOME}/.local/share/icons"
rm -rf "${DEST}"
cp -a "${SRC}" "${DEST}"
rm -f "${DEST}/install.sh"
gtk-update-icon-cache -f -t "${DEST}" 2>/dev/null || true
flatpak override --user --filesystem=xdg-data/icons:ro 2>/dev/null || true
gsettings set org.gnome.desktop.interface icon-theme 'HoussamOS-LiquidGlass' 2>/dev/null || true
if command -v plasma-apply-icontheme >/dev/null 2>&1; then
  plasma-apply-icontheme HoussamOS-LiquidGlass 2>/dev/null || true
elif command -v kwriteconfig6 >/dev/null 2>&1; then
  kwriteconfig6 --file kdeglobals --group Icons --key Theme HoussamOS-LiquidGlass
fi
echo "Installed to ${DEST}."
